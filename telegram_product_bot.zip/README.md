# Telegram Product Finder Bot

Поиск товаров на WB, Ozon, Яндекс.Маркете по фото и названию с анализом цен.

Разработано для деплоя на Railway.